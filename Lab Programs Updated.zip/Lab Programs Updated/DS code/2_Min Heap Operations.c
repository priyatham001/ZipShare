#include <stdio.h>

#define MAX_HEAP_SIZE 100

// Function to swap two integers
void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

// Function to perform min heapify on a subtree rooted at index i
void minHeapify(int arr[], int n, int i) 
{
	 int min=i;
	int left=i*2+1;
	int right=i*2+2;
	if(left<n&&arr[left]<arr[min])
	{
		min=left;
	}
	if(right<n&&arr[right]<arr[min])
	{
		min=right;
	}
	if(min!=i){
	swap(&arr[i],&arr[min]);
		minHeapify(arr,n,min);
	}
	
}

// Function to build a min heap
void buildMinHeap(int arr[], int n) {
    for (int i = n / 2 - 1; i >= 0; i--)
        minHeapify(arr, n, i);
}

// Function to display the min heap
void displayHeap(int arr[], int n) {
	printf("Min Heap: ");
	for(int i=0;i<n;i++)
		{
		printf("%d ",arr[i]);
		}
	printf("\n");

}

// Function to perform deletion (extract the minimum element) from the min heap
int extractMin(int arr[], int *n) {
	if(*n<=0)
		return -1;
	int temp;
	temp=arr[0];
	arr[0]=arr[*n-1];
	(*n)--;
	minHeapify(arr,*n,0);
	return temp;
}	
int main() {
    int arr[MAX_HEAP_SIZE];
    int n;

    printf("Enter no of elements: ");
    scanf("%d", &n);

    printf("Enter elements: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    buildMinHeap(arr, n);
    displayHeap(arr, n);

    printf("Extracting elements from the min heap:\n");
    while (n > 0) {
        int minElement = extractMin(arr, &n);
        if (minElement == -1)
            printf("Heap is empty.\n");
        else
            printf("Extracted: %d\n", minElement);
    }

    return 0;
}
