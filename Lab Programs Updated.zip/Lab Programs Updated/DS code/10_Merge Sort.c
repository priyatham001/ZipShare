#include <stdio.h>
void display(int arr[15], int n) {
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", arr[i]);
	printf("\n");
}
void merge(int arr[15], int low, int mid, int high) {
	int i = low, h = low, j = mid + 1, k, temp[15];
	while (i<=mid&&j<=high) {
		if (arr[i]<=arr[j]) {
			temp[h]=arr[i];
			i++;
			h++;
		} else {
			temp[h]=arr[j];
			j++;
			h++;
		
		}
		
		
	}

	if (i>mid) {
		while(j<=high)
			{
				temp[h]=arr[j];
				j++;
				h++;
			}
		
		
		
		
	} else {
		while(i<=mid)
			{
				temp[h]=arr[i];
				i++;
				h++;
			}
		
		
		
		
		
	}
	for (k = low; k <= high; k++) {
		arr[k] = temp[k];
	}
}
void splitAndMerge(int arr[15], int low, int high) {
	if(low<high)
	{
	
	int mid=(low+high)/2;
	splitAndMerge(arr,low,mid);
	splitAndMerge(arr,mid+1,high);
		merge(arr,low,mid,high);
	}
	
	
	
}

void main() {
	int arr[15], i, n;
	printf("Enter array size: ");
	scanf("%d", &n);
	printf("Enter %d elements: ", n);
	for (i = 0; i < n; i++) {
		scanf("%d", &arr[i]);
	}
	printf("Before sorting: ");
	display(arr, n);
	splitAndMerge(arr, 0, n - 1);
	printf("After sorting: ");
	display(arr, n);
}
