#include <stdio.h>

void display(int arr[15], int n) {
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", arr[i]);
	printf("\n");

	
}
int partition(int arr[15], int lb, int ub) {
	
	
	int pivot,start,end,temp;
	pivot=arr[lb];
	start=lb;
	end=ub;
	while(start<end)
		{
			
		while(arr[start]<=pivot)
			start++;

		while(arr[end]>pivot)
			end--;
		if(start<end)
		{
			temp=arr[start];
			arr[start]=arr[end];
			arr[end]=temp;
		}
			
		}
	
	temp=arr[lb];
	arr[lb]=arr[end];
	arr[end]=temp;
	return end;
	
}
void quickSort(int arr[15], int low, int high) {
	int j;
	if (low<high) {
		j = partition(arr,low,high);
		quickSort( arr,low,j-1);
		quickSort(arr,j+1,high);
	}
}

void main() {
	int arr[15], i, n;
	printf("Enter array size : ");
	scanf("%d", &n);
	printf("Enter %d elements : ", n);
	for (i = 0; i < n; i++) {
		scanf("%d", &arr[i]);
	}
	printf("Before sorting the elements are : ");
	display(arr, n);
	quickSort(arr, 0, n - 1);
	printf("After sorting the elements are : ");
	display(arr, n);
}
