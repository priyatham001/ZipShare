#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Define a structure for the graph
typedef struct {
    int V;
    int** adj;
} Graph;

typedef struct {
    int x, y;
} Edge;

typedef struct {
    Edge* edges;
    int size;
    int capacity;
} BCCStack;

// Function to create a new graph
Graph* createGraph(int vertices) {
    Graph* g = (Graph*)malloc(sizeof(Graph));
    g->V = vertices;
    g->adj = (int**)malloc(vertices * sizeof(int*));
    for (int i = 0; i < vertices; i++) {
        g->adj[i] = (int*)malloc(vertices * sizeof(int));
        for (int j = 0; j < vertices; j++) {
            g->adj[i][j] = 0;
        }
    }
    return g;
}

// Function to add an edge to the graph
void addEdge(Graph* g, int u, int v) {
    g->adj[u][v] = 1;
    g->adj[v][u] = 1;
}

// Function to create a new BCC stack
BCCStack* createBCCStack(int capacity) {
    BCCStack* stack = (BCCStack*)malloc(sizeof(BCCStack));
    stack->edges = (Edge*)malloc(capacity * sizeof(Edge));
    stack->size = 0;
    stack->capacity = capacity;
    return stack;
}

// Function to push an edge to the BCC stack
void pushBCCStack(BCCStack* stack, int u, int v) {
    if (stack->size == stack->capacity) {
        stack->capacity *= 2;
        stack->edges = (Edge*)realloc(stack->edges, stack->capacity * sizeof(Edge));
    }
    stack->edges[stack->size].x = u;
    stack->edges[stack->size].y = v;
    stack->size++;
}

// Function to pop an edge from the BCC stack
Edge popBCCStack(BCCStack* stack) {
    return stack->edges[--stack->size];
}

// Function to find bi-connected components
void findBiConnectedComponents(Graph* g) {
    
	int V=g->V;
		int disc[V],low[V],parent[V];
		int visited[V];
		for(int i=0;i<V;i++)
			{
				disc[i]=low[i]=parent[i]=-1;
				visited[i]=0;
				
			}
		BCCStack *stack =createBCCStack(V*V);
	int time=0,bccCount=0;
	void DFS(int u)
	{
		visited[u]=1;
		disc[u]=low[u]=++time;
		int children=0;
		for (int v=0;v<V;v++)
			{
				if(!g->adj[u][v])
					continue;
				if(!visited[v])
				{
					children++;
					parent[v]=u;
					pushBCCStack(stack,u,v);
					DFS(v);
					if(low[v]<low[u])
						low[u]=low[v];
		  if(((parent[u]==-1&&children>1)||(parent[u]!=-1&&low[v]>=disc[u])))
					{
						while(stack->size>0)
							{
								Edge e=popBCCStack(stack);
								if(e.x==u&&e.y==v)
									break;
							}
						bccCount++;
						
						
					}
				}
				else if(v!=parent[u]&&disc[v]<disc[u])
				{
					if(disc[v]<low[u])
						low[u]=disc[v];
					pushBCCStack(stack,u,v);
				}
			}
	}
	for(int i =0;i<V;i++)
		{
			if(!visited[i])
			{
				DFS(i);
				if(stack->size>0){
					popBCCStack(stack);
				bccCount++;
			}
		}
}
printf("%d\n",bccCount);
free(stack->edges);
free(stack);
 
 
}

// Main function
int main() {
    int vertices, edges;
    //printf("Enter number of vertices: ");
    scanf("%d", &vertices);
    //printf("Enter number of edges: ");
    scanf("%d", &edges);

    Graph* g = createGraph(vertices);
    //printf("Enter edges (u v):\n");
    for (int i = 0; i < edges; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        addEdge(g, u, v);
    }

    findBiConnectedComponents(g);

    // Free the graph memory
    for (int i = 0; i < vertices; i++) {
        free(g->adj[i]);
    }
    free(g->adj);
    free(g);

    return 0;
}
