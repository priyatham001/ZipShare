#include <stdio.h>
#include <stdlib.h>

typedef struct Job {
    int profit;
    int deadline;
    int id;
} Job;

int compare(const void* a, const void* b) {
    return ((Job*)b)->profit - ((Job*)a)->profit; // Sort by profit in descending order
}

void JobScheduling(Job jobs[], int n, int* countJobs, int* jobProfit) {




	qsort(jobs,n,sizeof(Job),compare);

	int maxDeadline=0;
	for(int i=0;i<n;i++)
		{
			if(jobs[i].deadline>maxDeadline)
				maxDeadline=jobs[i].deadline;
		}

	
	int *slot=(int *)malloc((maxDeadline+1)*sizeof(int));
		for(int i=0;i<=maxDeadline;i++)
			slot[i]=-1;
	*countJobs=0;
	*jobProfit=0;
	for(int i=0;i<n;i++)
		{
		for(int j=jobs[i].deadline;j>0;j--)
			{
				if(slot[j]==-1)
				{
					slot[j]=jobs[i].id;
					(*countJobs)++;
					(*jobProfit)+=jobs[i].profit;
					break;
				}
			}
		}
	free(slot);

}
int main() {
    int n;
    scanf("%d", &n);
    
    Job* jobs = (Job*)malloc(n * sizeof(Job));
    int info[3 * n];
    
    for (int i = 0; i < n; i++) {
        scanf("%d %d %d", &jobs[i].id, &jobs[i].deadline, &jobs[i].profit);
    }

    int countJobs, jobProfit;
    JobScheduling(jobs, n, &countJobs, &jobProfit);
    printf("%d %d\n", countJobs, jobProfit);
    
    free(jobs); // Free the allocated memory for jobs
    return 0;
}
