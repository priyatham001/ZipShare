#include <stdio.h>
#include <stdlib.h>

int knapsack(int *weights, int *values, int capacity, int n) {
    //code here..
         int dp[n + 1][capacity + 1];

    // Initialize DP table
    for (int i = 0; i <= n; i++) {
        for (int w = 0; w <= capacity; w++) {

            if (i == 0 || w == 0) {
                dp[i][w] = 0;
            }
            else if (weights[i - 1] <= w) {

                int include = values[i - 1] +
                              dp[i - 1][w - weights[i - 1]];

                int exclude = dp[i - 1][w];

                if (include > exclude)
                    dp[i][w] = include;
                else
                    dp[i][w] = exclude;
            }
            else {
                dp[i][w] = dp[i - 1][w];
            }
        }
    }

    return dp[n][capacity];
}


int main() {
    int n;

    // Read number of items
    scanf("%d", &n);

    // Allocate memory for values and weights
    int *values = (int *)malloc(n * sizeof(int));
    int *weights = (int *)malloc(n * sizeof(int));

    // Read values and weights of items
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &values[i],&weights[i]);
    }

    int capacity;
    scanf("%d", &capacity);

    // Calculate and print the maximum profit
    printf("%d\n", knapsack(weights, values, capacity, n));

    // Free allocated memory
    free(values);
    free(weights);

    return 0;
}
