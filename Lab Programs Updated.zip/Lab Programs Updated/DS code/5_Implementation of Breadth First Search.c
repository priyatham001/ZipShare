#include <stdio.h>
#include <stdlib.h>

#define MAX 99

struct node {
    struct node *next;
    int vertex;
};
typedef struct node *GNODE;

GNODE graph[20];
int visited[20];
int queue[MAX];
int front=-1,rear=-1;
void enqueue(int item)
{
	if(rear==MAX-1)
		return;
	if(front==-1)
		front++;
	rear++;
		queue[rear]=item;
	
}
int dequeue(){
	if(front==-1||front>rear)
		return -1;
	return queue[front++];
}
void BFS(int v)
{
	GNODE p;
	visited[v]=1;
	enqueue(v);
	while(front!=-1&&front<=rear)
		{
			v=dequeue();
			printf("\n%d",v);
			p=graph[v];
			while(p!=NULL)
				{
					if(!visited[p->vertex])
					{
						visited[p->vertex]=1;
						enqueue(p->vertex);
					}
					p=p->next;
				}
		}

}
int main() {
    int n, E, s, d, v, i;
    GNODE p, q;

    // Initialize graph to NULL
    for (i = 0; i < 20; i++)
        graph[i] = NULL;

    printf("Enter no of vertices: ");
    scanf("%d", &n);

    printf("Enter no of edges: ");
    scanf("%d", &E);

    for (i = 1; i <= E; i++) {
        printf("Enter source: ");
        scanf("%d", &s);
        printf("Enter destination: ");
        scanf("%d", &d);

        q = (GNODE)malloc(sizeof(struct node));
        q->vertex = d;
        q->next = NULL;

        if (graph[s] == NULL)
            graph[s] = q;
        else {
            p = graph[s];
            while (p->next != NULL)
                p = p->next;
            p->next = q;
        }
    }

    for (i = 1; i <= n; i++)
        visited[i] = 0;

    printf("Enter Start Vertex for BFS: ");
    scanf("%d", &v);

    printf("BFS of graph: ");
    BFS(v);
    printf("\n");

    return 0;
}
