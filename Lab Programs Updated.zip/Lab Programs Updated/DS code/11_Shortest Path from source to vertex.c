#include <stdio.h>
#include <limits.h>
#include <stdbool.h>

#define MAX_V 100 

int minDistance(int dist[], bool sptSet[], int V) {

	int min=INT_MAX;
	int min_index=-1;
	for(int v=0;v<V;v++)
		{
			if(!sptSet[v]&&dist[v]<=min)
			{
				min=dist[v];
				min_index=v;
			}
		}
		return min_index;
	
}

void printSolution(int dist[], int V) {
    printf("Vertex \t Distance from Source\n");
    for (int i = 0; i < V; i++) {
        printf("%d \t %d\n", i, dist[i]);
    }
}

void dijkstra(int graph[MAX_V][MAX_V], int src, int V) {

	int dist[MAX_V];
	bool sptSet[MAX_V];
		for (int i=0;i<V;i++)
			{
				dist[i]=INT_MAX;
				sptSet[i]=false;
			}
	dist[src]=0;

		for(int count=0;count<V-1;count++)
			{
				int u=minDistance(dist,sptSet,V);
				if(u==-1)
					break;
				sptSet[u]=true;

				for(int v=0;v<V;v++)
					{
						if(!sptSet[v]!=0&&graph[u][v]!=0&&dist[u]!=INT_MAX&&dist[u]+graph[u][v]<dist[v]){
							dist[v]=dist[u]+graph[u][v];
						}
					}
			}
	printSolution(dist,V);
	
}

int main() {
    int graph[MAX_V][MAX_V];
    int V, src;

    printf("number of vertices: ");
    scanf("%d", &V);

    if (V > MAX_V) {
        printf("Number of vertices exceeds maximum allowed (%d)\n", MAX_V);
        return 1;
    }

    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            graph[i][j] = 0;
        }
    }

    printf("adjacency matrix:\n");
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            printf("Weight from %d to %d: ", i, j);
            scanf("%d", &graph[i][j]);
        }
    }

    printf("Enter the source vertex: ");
    scanf("%d", &src);

    if (src < 0 || src >= V) {
        printf("Invalid source vertex\n");
        return 1;
    }

    dijkstra(graph, src, V);

    return 0;
}
