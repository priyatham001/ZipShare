#include <stdio.h>

#define MAX_HEAP_SIZE 100

// Function to swap two integers
void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

// Function to perform max heapify on a subtree rooted at index i
void maxHeapify(int a[], int n, int i) {
	int largest=i;
	int left=2*i+1;
	int right=2*i+2;
	if(left<n&&a[largest]<a[left])
		largest=left;
	if(right<n&&a[largest]<a[right])
		largest=right;
	if(largest!=i)
	{
		swap(&a[i],&a[largest]);
			maxHeapify(a,n,largest);
	}



}

// Function to build a max heap
void buildMaxHeap(int a[], int n) 
{
	int i;
	for(i=(n/2)-1;i>=0;i--){
		maxHeapify(a,n,i);
	}
	

}

// Function to display the max heap
void displayHeap(int a[], int n) {
printf("Max Heap: ");
	for(int i=0;i<n;i++)
		{
			printf("%d ",a[i]);
			
		}
printf("\n");

}

// Function to perform deletion (extract the maximum element) from the max heap
int extractMax(int a[], int *n)
{
	if(*n<=0)
	{
		return -1;
	}
	int max=a[0];
	a[0]=a[*n-1];
	(*n)--;
	maxHeapify(a,*n,0);
		return max;

}

int main() {
    int arr[MAX_HEAP_SIZE];
    int n;

    printf("Enter no of elements: ");
    scanf("%d", &n);

    printf("elements: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    buildMaxHeap(arr, n);
    displayHeap(arr, n);

    printf("Extracting elements from max heap:\n");
    while (n > 0) {
        int maxElement = extractMax(arr, &n);
        if (maxElement == -1)
            printf("Heap is empty.\n");
        else
            printf("Extracted: %d\n", maxElement);
    }

    return 0;
}
