#include <stdio.h>
#include <stdlib.h>

// Define structure for an AVL Tree node
struct Node {
    int key;
    struct Node* left;
    struct Node* right;
    int height;
};

struct DeletionResult {
    struct Node* root;
    int deleted; // 1 if deleted, 0 if not found
};

// Function to get the height of the tree
int height(struct Node* N) {
    if (N == NULL)
        return 0;
    return N->height;
}

// Function to get the maximum of two integers
int max(int a, int b) {
    return (a > b) ? a : b;
}

// Function to allocate a new node
struct Node* newNode(int key) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->key = key;
    node->left = NULL;
    node->right = NULL;
    node->height = 1;  // New node is initially added at leaf
    return node;
}

// Right rotate subtree rooted with y
struct Node* rightRotate(struct Node* y) {
    struct Node* x = y->left;
    struct Node* T2 = x->right;

    // Perform rotation
    x->right = y;
    y->left = T2;

    // Update heights
    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;
}

// Left rotate subtree rooted with x
struct Node* leftRotate(struct Node* x) {
    struct Node* y = x->right;
    struct Node* T2 = y->left;

    // Perform rotation
    y->left = x;
    x->right = T2;

    // Update heights
    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

// Get balance factor of node N
int getBalance(struct Node* N) {
    if (N == NULL)
        return 0;
    return height(N->left) - height(N->right);
}

// Recursive function to insert a key in the subtree rooted with node and return the new root
struct Node* insert(struct Node* node, int key) {
	if(node==NULL)
	{
		struct Node *a=newNode(key);
		return a;
	}
	else if(node->key>key)
	{
		node->left=insert(node->left,key);
	}
	else if(node->key<key)
	{
		node->right=insert(node->right,key);
	}
	node->height=1+max(height(node->left),height(node->right));
	if(getBalance(node)>1&&getBalance(node->left)>=0)
	{
		node=rightRotate(node);
	}
	else if(getBalance(node)<-1&&getBalance(node->right)<=0)
	{
		node=leftRotate(node);
	}
	else if(getBalance(node)>1&&getBalance(node->left)<0)
	{
		node->left=leftRotate(node->left);
		node=rightRotate(node);
	}
	else if(getBalance(node)<-1&&getBalance(node->right)>0)
	{
		node->right=rightRotate(node->right);
		node=leftRotate(node);
	}
    
    return node;
    
    
}

// Function to find the node with minimum value in the tree
struct Node* minValueNode(struct Node* node) {
    struct Node* current = node;

    // Find the leftmost leaf
    while (current->left != NULL)
        current = current->left;

    return current;
}

// Recursive function to delete a node with a given key from subtree with given root
struct DeletionResult deleteNode(struct Node* root, int key) {

	struct DeletionResult a;
	a.deleted=0;
	if(root==NULL)
	{
		a.root=NULL;
		
		return a;
	}
	
		if(root->key>key)
		{
			struct DeletionResult temp=deleteNode(root->left,key);
			
			root->left=temp.root;
		    a.deleted=temp.deleted;
			
		}
		else if(root->key<key)
		{
			
			struct DeletionResult temp=deleteNode(root->right,key);
			root->right=temp.root;
			a.deleted=temp.deleted;
		}
		else
		{
			a.deleted=1;
			
			if(root->left==NULL&&root->right==NULL)
			{
				free(root);
				a.root=NULL;
				return a;
			}
			else if(root->left!=NULL&&root->right==NULL)
			{struct Node *p;
				p=root->left;
				a.root=p;
				free(root);
				return a;
			}
			else if(root->right!=NULL&&root->left==NULL)
			{struct Node *p;
				p=root->right;
				a.root=p;
			 free(root);
				return a;
			}
			else 
			{
				struct Node *p;
				p=root->left;
				while(p->right!=NULL)
					{
						p=p->right;
					}
				root->key=p->key;
				struct DeletionResult temp =deleteNode(root->left,p->key);
				root->left=temp.root;
				a.deleted=1;
			}
			
		}
			root->height=1+max(height(root->left),height(root->right));
			if(getBalance(root)>1&&getBalance(root->left)>=0)
			{
				root=rightRotate(root);
			}
			else if(getBalance(root)<-1&&getBalance(root->right)<=0)
			{
				root=leftRotate(root);
			}
			else if(getBalance(root)>1&&getBalance(root->left)<0)
			{
				root->left=leftRotate(root->left);
				root=rightRotate(root);
			}
			else if(getBalance(root)<-1&&getBalance(root->right)>0)
			{
				root->right=rightRotate(root->right);
				root=leftRotate(root);
			}
	a.root=root;
	return a;
			
			

	}
	




// Function to perform in-order traversal
void inOrderTraversal(struct Node* root) {
	struct Node *temp=root;
    if(root==NULL)
	{
		return;
	}
	inOrderTraversal(temp->left);
	printf("%d ",temp->key);
	inOrderTraversal(temp->right);
    
    
    
}

// Function to write in-order traversal to a file
void writeToFile(struct Node* root, FILE* file) {
    if (root != NULL) {
        writeToFile(root->left, file);
        fprintf(file, "%d ", root->key);
        writeToFile(root->right, file);
    }
}

int main() {
    char inputFileName[100], outputFileName[100];
    int choice, element;

    printf("Input file name: ");
    scanf("%s", inputFileName);

    FILE* inputFile = fopen(inputFileName, "r");

    if (inputFile == NULL) {
        printf("Error opening input file\n");
        return 1;
    }

    int n;
    struct Node* root = NULL;
	
    // Read the number of elements and insert into AVL tree
    fscanf(inputFile, "%d", &n);
    for (int i = 0; i < n; i++) {
        fscanf(inputFile, "%d", &element);
        root = insert(root, element);
    }
    
    printf("In-order traversal:\n");
    inOrderTraversal(root);

    fclose(inputFile);

    while (1) {
        printf("\n1. Insert\n2. Delete\n3. Write to file and exit\nChoice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Element: ");
                scanf("%d", &element);
                root = insert(root, element);
                printf("In-order traversal:\n");
                inOrderTraversal(root);
                break;

            case 2: // Deleting an element
                printf("Element: ");
                scanf("%d", &element);
                struct DeletionResult deleteResult = deleteNode(root, element);
                root = deleteResult.root;
                if (deleteResult.deleted) {
                    printf("Deleted %d\n", element);
                } else {
                    printf("%d not found\n", element);
                }
                printf("In-order traversal:\n");
                inOrderTraversal(root);
                break;

            case 3:
                printf("Output file name: ");
                scanf("%s", outputFileName);
                FILE* outputFile = fopen(outputFileName, "w");
                if (outputFile == NULL) {
                    printf("Error opening output file");
                    return 1;
                }
                writeToFile(root, outputFile);
                fclose(outputFile);
                printf("AVL Tree written to file");
                return 0;

            default:
                printf("Invalid choice");
                break;
        }
    }

    return 0;
}
