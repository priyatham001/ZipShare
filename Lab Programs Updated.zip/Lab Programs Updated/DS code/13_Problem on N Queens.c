#include <stdio.h>
int N;
int board[100][100];


int is_attack(int i,int j) {
        //This is the function to check if the cell is attacked or not

    //check if there is any queen in row or column

    //check for diagonals if found return 1 else return 0
     for(int k = 0; k < N; k++) {
        if(board[i][k] == 1)
            return 1;
    }

    // Check column
    for(int k = 0; k < N; k++) {
        if(board[k][j] == 1)
            return 1;
    }

    // Check upper-left diagonal
    int x = i - 1;
    int y = j - 1;
    while(x >= 0 && y >= 0) {
        if(board[x][y] == 1)
            return 1;
        x--;
        y--;
    }

    // Check upper-right diagonal
    x = i - 1;
    y = j + 1;
    while(x >= 0 && y < N) {
        if(board[x][y] == 1)
            return 1;
        x--;
        y++;
    }

    // Check lower-left diagonal
    x = i + 1;
    y = j - 1;
    while(x < N && y >= 0) {
        if(board[x][y] == 1)
            return 1;
        x++;
        y--;
    }

    // Check lower-right diagonal
    x = i + 1;
    y = j + 1;
    while(x < N && y < N) {
        if(board[x][y] == 1)
            return 1;
        x++;
        y++;
    }
    return 0;
}

int N_queen(int n) {
    int i,j;
    if(n == 0)
        return 1;
        for(i = 0; i < N; i++) {

        for(j = 0; j < N; j++) {

            // Check whether position is safe
            if(board[i][j] == 0 && is_attack(i, j) == 0) {

                // Place queen
                board[i][j] = 1;

                // Place remaining queens
                if(N_queen(n - 1))
                    return 1;

                // Backtrack
                board[i][j] = 0;
            }
        }
    }

    return 0;

     // check whether we can put queen to this posotion or not
     // the condition for this is the queen should not be placed if it is in attacking mode
     // or if the place is already occupied
     // continue this wiht the remaining queens also
}

int main() {
    printf("Enter the value of N for NxN chessboard: ");
    scanf("%d",&N);

    int i,j;
    for(i = 0 ;i < N; i++) {
        for(j = 0; j < N; j++) {
            board[i][j] = 0;
        }
    }
    N_queen(N);
    for(i = 0 ;i < N; i++) {
        for(j = 0; j < N; j++)
            printf("%d\t",board[i][j]);
        printf("\n");
    }
}
