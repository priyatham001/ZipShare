-- Write your query here..
select max(price) maximum_price from products;
