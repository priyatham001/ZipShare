CREATE OR REPLACE FUNCTION check_scholarship(marks INTEGER, attendance INTEGER)
RETURNS TEXT AS $$
DECLARE
    scholarship_status TEXT;
BEGIN
    -- write your code here...  
    if marks >= 50 then
	if attendance >= 85 then scholarship_status:='Scholarship Approved';
	else scholarship_status:='Attendance Requirement Not Met';
    end if;
	else
	scholarship_status:='Not Eligible';
end if ;
    return scholarship_status;
END;
$$ LANGUAGE plpgsql;
