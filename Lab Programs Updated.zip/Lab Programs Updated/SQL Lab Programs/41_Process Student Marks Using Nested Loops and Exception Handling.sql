CREATE OR REPLACE FUNCTION process_student_marks()
RETURNS TEXT AS
$$
DECLARE
    -- Write your code here..
	cls RECORD;
	stu RECORD;
invalid_count INTEGER := 0;
 
BEGIN
    -- Iterate through all classes
	FOR cls IN
	SELECT * From classes ORDER BY class_id
	LOOP
	FOR stu IN
	SELECT * FROM students
	WHERE class_id = cls.class_id
	ORDER BY student_id
	LOOP
	BEGIN
	IF stu.marks < 0 OR stu.marks > 100 THEN
	RAISE EXCEPTION 'Invalid Marks';
END IF;
RAISE NOTICE 'Student: %, Mark: %', stu.student_name, stu.marks;
EXCEPTION
	WHEN OTHERS THEN 
	invalid_count := invalid_count + 1;
RAISE NOTICE 'Skipping Student: % (Invalid Mark: %)',
	stu.student_name, stu.marks;
END;
END LOOP;
END LOOP;
RETURN invalid_count;
END;
$$
LANGUAGE plpgsql;
