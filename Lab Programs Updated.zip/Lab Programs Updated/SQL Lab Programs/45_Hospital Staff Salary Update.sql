/*Type Content here...*/
create or replace function update_salary()
returns TEXT
as $$
begin
	update emp
	set salary = salary * 1.10
	where bonus is null;
	RETURN 'Salary updated';
end;
$$ language plpgsql;
