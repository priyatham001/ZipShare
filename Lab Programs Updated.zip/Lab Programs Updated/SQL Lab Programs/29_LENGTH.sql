-- Write your query here..
select name,length(name) from employees;
