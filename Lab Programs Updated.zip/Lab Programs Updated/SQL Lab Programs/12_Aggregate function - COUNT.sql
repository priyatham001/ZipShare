-- Write your query here..
select count(prod_id)total_products from products;
