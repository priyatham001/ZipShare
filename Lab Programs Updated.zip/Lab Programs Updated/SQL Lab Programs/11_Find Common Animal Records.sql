-- Write your query here
select animal_name from forest_rangers intersect select animal_name from eco_volunteers
order by animal_name;
