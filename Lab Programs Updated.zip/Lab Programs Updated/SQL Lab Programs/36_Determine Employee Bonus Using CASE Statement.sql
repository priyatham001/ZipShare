CREATE OR REPLACE FUNCTION check_bonus(rating INTEGER)
RETURNS TEXT AS $$
DECLARE
    bonus_category TEXT;
BEGIN
    CASE 
    rating
    when 1 then bonus_category:='Bronze Bonus';
    when 2 then bonus_category:='Silver Bonus';
    when 3 then bonus_category:='Gold Bonus';
    else
		bonus_category:='Invalid Rating';
end case;
return bonus_category;
END;
$$ LANGUAGE plpgsql;
