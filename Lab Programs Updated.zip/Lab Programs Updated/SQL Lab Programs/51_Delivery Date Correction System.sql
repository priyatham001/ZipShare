CREATE OR REPLACE FUNCTION correct_delivery_date()
RETURNS TRIGGER AS $$
 begin
	if New.delivery_date < New.dispatch_date then
		New.delivery_date := New.dispatch_date;
	end if;
	return NEW;
 END;

$$ LANGUAGE plpgsql;
create trigger before_delivery_insert
before insert on deliveries
for each row
execute function correct_delivery_date();
