-- Write your query here..
select
name,to_number (salary,'99999999999999999') as salary from employees;
