CREATE OR REPLACE FUNCTION add_grace_marks()
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
  --write your code here...
student_cursor CURSOR FOR SELECT * FROM students FOR UPDATE;
    rec RECORD;
BEGIN
	    OPEN student_cursor;

    loop
		        FETCH student_cursor INTO rec;
       EXIT WHEN NOT FOUND;
        UPDATE students
			SET marks = rec.marks + 5
			WHERE CURRENT OF student_cursor;
    END LOOP;
CLOSE student_cursor;
END;
$$;
