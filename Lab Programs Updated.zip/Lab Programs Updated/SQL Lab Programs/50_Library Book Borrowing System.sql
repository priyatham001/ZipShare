CREATE OR REPLACE FUNCTION update_book_copies()
RETURNS TRIGGER AS $$
 begin
	update books
	set available_copies = available_copies - 1
	where book_id = New.book_id;
 return New;
 end;
$$ LANGUAGE plpgsql;
create trigger after_borrow_insert
after insert on borrow_records
for each row
execute function update_book_copies(); 
