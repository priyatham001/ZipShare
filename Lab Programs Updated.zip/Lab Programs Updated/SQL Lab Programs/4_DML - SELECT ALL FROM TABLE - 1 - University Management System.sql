drop table if exists courses;
	-- create the table
Create table courses
(
	course_id SERIAL Primary Key,
	course_name VARCHAR(255),
	credits INT
);
-- insert the data
INSERT INTO Courses
(course_id,course_name,credits)
VALUES
(1,'Database Management',4),
(2,'Software Engineering',3),
(3,'Computer Networks',3);
-- retrieve the data
SELECT * FROM courses;
