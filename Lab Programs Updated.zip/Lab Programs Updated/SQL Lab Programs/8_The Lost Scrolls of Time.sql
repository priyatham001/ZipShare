-- Write your query here
select scroll_name from scrolls where scroll_id in ( select scroll_id from discoveries where discovered_date < '2000-01-01')order by scroll_name;
