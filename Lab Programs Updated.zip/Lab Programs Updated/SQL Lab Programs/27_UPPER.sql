-- Write your query here..
select upper(name) as name from employees;
