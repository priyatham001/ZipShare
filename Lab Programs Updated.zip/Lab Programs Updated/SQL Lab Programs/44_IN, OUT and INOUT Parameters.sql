CREATE OR REPLACE PROCEDURE add_numbers(
     
     --complete the code
     
    in  a INT,                -- Input parameter for the first integer
     in  b INT,                -- Input parameter for the second integer
    inout   initial_result INT, -- INOUT parameter to receive and update the result
     out  final_result INT     -- Output parameter to return the final sum

)
language plpgsql
as $$
begin
initial_result := a+b;
final_result := initial_result;
end;
$$;
-- Complete the code
