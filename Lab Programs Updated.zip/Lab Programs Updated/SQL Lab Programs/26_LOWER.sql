-- Write your query here..
select lower(name) as name from employees;
