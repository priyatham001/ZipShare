-- Write your query here
-- select cns from tns [where c];
--select * from employees;
--select name from employees; 
--select id,name from employees;
--select * from employees where id=1;
--select * from employees where department='HR';
--select * from employees where salary>50000;

	select name from employees where salary > any ( select salary from employees where department= 'HR' )
