CREATE OR REPLACE FUNCTION add_employee(emp_id INT, emp_name TEXT)
RETURNS TEXT
LANGUAGE plpgsql
AS $$
BEGIN
      -- Write your code here..
insert into employees(employee_id, employee_name)
values(emp_id, emp_name);
return 'Employee added successfully';
exception
	when unique_violation then 
	return 'Employee ID already exists';
      
END;
$$;
