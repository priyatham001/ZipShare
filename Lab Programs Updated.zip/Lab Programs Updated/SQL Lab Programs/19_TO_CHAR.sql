-- Write your query here..
select
name,to_char(salary,'FM9,999,999,999') as salary from employees;
