/* Write your code here...*/
    
create or replace function check_signal_strength(signal INT)
returns text
language plpgsql
as $$
begin
if signal >= 0 then
return 'Valid Signal';
else
raise exception 'Invalid signal detected';
end if;
end;
$$;
