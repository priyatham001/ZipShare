-- Write your query here
select light_id,location from streetlights where light_id not in(select light_id from malfunctions)order by light_id;
