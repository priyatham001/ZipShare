CREATE OR REPLACE FUNCTION countdown(v_start INTEGER)
RETURNS TEXT AS $$
DECLARE
    v_countdown TEXT := '';
BEGIN
    WHILE    v_start >= 0 LOOP
	v_countdown := v_countdown || v_start ||' ';
v_start := v_start - 1;
    END LOOP;
    RETURN v_countdown;
END $$ LANGUAGE plpgsql;
