-- Write your query here
select location_name from residential_waste where waste_collected is not NULL
UNION 
select location_name from commercial_waste where waste_collected is not NULL
