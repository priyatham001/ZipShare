--create the table
Create table Trafficviolations
(
    violation_id SERIAL Primary Key,
	vehicle_number VARCHAR(15),
	driver_name VARCHAR(50),
	violation_type VARCHAR(30),
	fine_amount DECIMAL(8,2),
	violation_date DATE
);

	Insert into Trafficviolations
(violation_id,vehicle_number,driver_name,violation_type,fine_amount,violation_date
)
VALUES
(1,'AB123CD','John Doe','Speeding',100.50,'2024-01-15'),
(2,'XY987ZT','Alice Johnson','Red Signal Jump',150.00,'2024-02-10'),
(3,'LM456PQ','Robert Smith','No Seatbelt',50.75,'2024-03-05');
