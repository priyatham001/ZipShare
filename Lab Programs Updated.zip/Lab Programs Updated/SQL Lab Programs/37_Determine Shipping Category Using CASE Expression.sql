CREATE OR REPLACE FUNCTION check_shipping(order_amount INTEGER)
RETURNS TEXT AS $$
DECLARE
    shipping_category TEXT;
BEGIN
   RETURN CASE
   when order_amount >= 1000 then 'Free Shipping'
   when order_amount >= 500 then 'Discounted Shipping'
   when order_amount >= 1 then 'Standard Shipping'
else
	'Invalid Amount'
END CASE;
END;
$$ LANGUAGE plpgsql;
