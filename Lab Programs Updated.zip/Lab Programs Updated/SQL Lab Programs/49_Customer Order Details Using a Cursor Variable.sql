CREATE OR REPLACE FUNCTION display_order_details()
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
   -- write your code here...
	    order_cur REFCURSOR;
    rec RECORD;
BEGIN

	    OPEN order_cur FOR 
	        SELECT order_id, customer_name, product_name, quantity, total_amount 
	        FROM orders;
    LOOP
		        FETCH order_cur INTO rec;
        EXIT WHEN NOT FOUND;
        RAISE NOTICE 'Order ID: %, Customer: %, Product: %, Quantity: %, Amount: %', 
			            rec.order_id, rec.customer_name, rec.product_name, rec.quantity, rec.total_amount;
    END LOOP;
    CLOSE order_cur;
END;
$$;
