-- Type Content here...
BEGIN;
insert into student_marks (student_name, marks)
values ('Alice', 85);
insert into student_marks (student_name, marks)
values ('Bob', 92);
commit;
