-- Write your query here..
select avg(price) average_price from products;
