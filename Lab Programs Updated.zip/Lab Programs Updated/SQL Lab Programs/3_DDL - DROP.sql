-- write your code here..
drop table employees;
