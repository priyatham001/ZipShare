CREATE OR REPLACE FUNCTION sum_numbers(v_max INTEGER)
RETURNS INTEGER AS $$
DECLARE
    v_sum INTEGER := 0;
BEGIN
    FOR    i IN 1..$1 LOOP
    v_sum := v_sum + i;
    END LOOP;
    RETURN v_sum;
END $$ LANGUAGE plpgsql;
