BEGIN;
insert into student_marks (student_name, marks)
	values ('Alice', 85);
	savepoint sp1;
insert into student_marks (student_name, marks)
	values ('Bob', 92);
ROLLBACK TO savepoint sp1;
COMMIT;
