CREATE OR REPLACE FUNCTION update_book_status()
RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
    -- write your code here...
	book_cursor cursor for select book_id, available_copies from books for update;
	rec record;
BEGIN
   -- write your code here...
	open book_cursor;
	loop
		fetch book_cursor into rec;
		exit when not found;
		if rec.available_copies > 0 then
			update books
			set status = 'Available'
			where book_id = rec.book_id;
		else
			update books
			set status = 'Out of Stock'
			where book_id = rec.book_id;
		END IF;
	END LOOP;
	close book_cursor;

END;
$$;
