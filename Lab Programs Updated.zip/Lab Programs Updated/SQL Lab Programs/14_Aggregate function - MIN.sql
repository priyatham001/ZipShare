-- Write your query here..
select min(price) minimum_price from products;
