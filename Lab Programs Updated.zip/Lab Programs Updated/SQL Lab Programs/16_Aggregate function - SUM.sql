-- Write your query here..
select sum(price) total_price from products;
