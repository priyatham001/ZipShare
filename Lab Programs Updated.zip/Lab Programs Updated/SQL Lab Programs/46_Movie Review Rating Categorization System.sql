CREATE OR REPLACE FUNCTION updated_feedback(min_score NUMERIC)
RETURNS VOID
AS $$

DECLARE
   -- record to hold each row from the cursor
	rec RECORD;
   -- Declare a cursor, to loop through all literature reviews
  cur CURSOR FOR SELECT review_id, review_score from movie_reviews;
  
BEGIN
   -- Open the cursor to begin iteration
   open cur;
 
   -- Loop through each review record one by one
   loop
		fetch cur into rec;
		exit when not found;

		if rec.review_score >= min_score then
			update movie_reviews
			set feedback_category = 'Blockbuster'
			where review_id = rec.review_id;
		elseif rec.review_score >= 7.0 then
			update movie_reviews
			set feedback_category = 'Super Hit'
			where review_id = rec.review_id;
		elseif rec.review_score >= 5.0 then
			update movie_reviews
			set feedback_category = 'Hit'
			where review_id = rec.review_id;
		else
			update movie_reviews
			set feedback_category = 'Flop'
			where review_id = rec.review_id;
		END IF; 
   END LOOP;
	close cur;
END;
$$ LANGUAGE plpgsql;
