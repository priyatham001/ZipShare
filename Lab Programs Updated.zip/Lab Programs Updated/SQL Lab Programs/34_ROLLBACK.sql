-- Write your query here...
begin;
insert into student_marks (student_name,marks)
values ('Alice', 85);
insert into student_marks (student_name,marks)
values ('Bob', 92);
savepoint sp1;
insert into student_marks (student_name,marks)
values ('Charlie', 90);
rollback to savepoint sp1;
commit;
