-- Task 1
drop view old_trip_participants;


-- Task 2
create view trip_participants as
select
full_name,trip_location from travel_records;
