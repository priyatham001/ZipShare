-- Type Content here...
--select max(spocket) from stud where spocket <600;
--select gn(c),gc from table name group by gc;
--select sarea,sum(spocket) from stud group by sarea;
--select sarea,count(*) from stud group by sarea;
--select sdept,count(*) from stud group by sdept;
--select count(*) from stud where sage=20;
--select sage,count(*) from stud group by sage;
--display max age of students for each area
--select sarea,max(sage) from stud group by sarea; 
--select count(*) from stud where sage>18 group by sarea ;
--display number of student in each area that has a count greater than 1
--select sarea,count(*) from stud group by sarea having count(*)>1;  
select sarea,sum(spocket) result from stud group by sarea having max(spocket)
<600;
