/* Write your code here...*/
    
create or replace function get_employee_salary(p_emp_id int)
returns numeric(10,2)
as $$
declare
emp_salary numeric(10,2);
begin
select salary
into emp_salary
from employees
where employees.emp_id = p_emp_id;
if not found then
raise exception 'Employee not found';
end if;
return emp_salary;
end;
$$ language plpgsql;
