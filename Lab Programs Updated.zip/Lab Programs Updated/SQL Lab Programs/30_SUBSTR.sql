-- Write your query here..
select name,substr(name,'2','4') as substring from employees;
