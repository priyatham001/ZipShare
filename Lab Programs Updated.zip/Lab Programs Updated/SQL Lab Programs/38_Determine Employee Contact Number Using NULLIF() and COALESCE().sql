CREATE OR REPLACE FUNCTION check_contact(contact_number TEXT)
RETURNS TEXT AS $$
DECLARE
    result_contact TEXT;
BEGIN
   --write your code here ..
   result_contact:=
	COALESCE(NULLIF(contact_number,''),'not Available');
   return result_contact;
   
   
END;
$$ LANGUAGE plpgsql;
