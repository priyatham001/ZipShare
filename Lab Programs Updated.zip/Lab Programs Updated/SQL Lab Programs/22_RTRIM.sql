-- write your query here..
select rtrim(name) as name from employees;
