package q28178;
import java.util.Scanner;

class Author {
    Scanner sc =new Scanner(System.in);

    String  fullName;
    void inputFullName()
    {
        fullName=sc.nextLine();
    }
    void displayFullName()
    {
        System.out.println(fullName);
    }
}

class BookAuthor extends Author{

    int publishedBooks;

    void inputBooks()
    {
        publishedBooks=sc.nextInt();
    }
    void displayBooks()
    {
        System.out.println(publishedBooks);
    }
    String generatePenName()
    {
        String n = fullName.substring(0,3);
        String str2= fullName.substring(fullName.length()-3,fullName.length());
        return n.concat(str2);
    }

}

public class AuthorInfo {
    public static void main(String[] args) {
        // Creating an instance of BookAuthor
        BookAuthor bookAuthor = new BookAuthor();

        // Input for the author's full name
        bookAuthor.inputFullName();

        // Input for the number of published books
        bookAuthor.inputBooks();

        // Displaying the author's full name
        bookAuthor.displayFullName();

        // Displaying the number of published books
        bookAuthor.displayBooks();

        // Displaying the generated pen name
        String penName = bookAuthor.generatePenName();
        System.out.println(penName);
    }
}
