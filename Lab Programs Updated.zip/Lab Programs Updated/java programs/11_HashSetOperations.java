package q74592;
import java.util.*;

public class HashSetOperations {
    public static void main(String args[]){
        Scanner sc =new Scanner(System.in);
        HashSet<Integer> hs=new HashSet<Integer>();
        int n = sc.nextInt();
        int i;
        for(i=0;i<n;i++)
        {
            int e=sc.nextInt();
            hs.add(e);
        }
        HashSet<Integer> hs1=new HashSet<Integer>();
        int m =sc.nextInt();
        for(i=0;i<m;i++)
        {
            hs1.add(sc.nextInt());
        }
        HashSet<Integer> op =new HashSet<Integer>();
        op.addAll(hs);
        op.addAll(hs1);
        System.out.println(op);
        op.clear();
        op.addAll(hs);
        op.retainAll(hs1);
        System.out.println(op);
        op.clear();
        op.addAll(hs);
        op.removeAll(hs1);
        System.out.println(op);
        sc.close();
    }
}
