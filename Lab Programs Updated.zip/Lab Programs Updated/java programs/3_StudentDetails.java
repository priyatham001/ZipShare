package q86064;
import java.util.Scanner;

class Student {

    int student_id;
    String student_name;
    void display(){
        System.out.println("ID: "+student_id+", Name: "+student_name);
    }

}

public class StudentDetails {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Student s1=new Student();
        s1.student_id=sc.nextInt();
        s1.student_name=sc.next();

        s1.display();
        sc.close();
    }
}
