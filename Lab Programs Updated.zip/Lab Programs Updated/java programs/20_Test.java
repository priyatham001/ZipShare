package q77447;
import java.util.Scanner;
import myPack.Hello;

public class Test {
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();     
        Hello h = new Hello();           
        h.show(name);                   
        sc.close();
    }
}
