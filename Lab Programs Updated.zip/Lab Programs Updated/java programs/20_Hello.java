package myPack;
public class Hello
	{
		public void show(String name)
		{
			System.out.printf("Hello %s, package is imported\n",name);
		}
	}
