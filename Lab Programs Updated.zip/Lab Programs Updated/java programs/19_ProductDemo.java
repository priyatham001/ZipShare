package q36544;
import java.util.Scanner;
interface Product {
    double getPrice();
    void calculateTotal();
}

class Note implements Product {
    private double price;
    private int quantity;

    Note(double p,int q)
    {
        this.price=p;
        this.quantity=q;
    }
    public double getPrice()
    {
        return price;
    }
    public void calculateTotal()
    {
        System.out.printf("Total cost of %d notes: %.1f\n",quantity,quantity*price);
    }
}

public class ProductDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Price of one note: ");
        double price = scanner.nextDouble();

        System.out.print("Quantity: ");
        int quantity = scanner.nextInt();
        Note note = new Note(price, quantity);

        note.calculateTotal();

        scanner.close();
    }
}
