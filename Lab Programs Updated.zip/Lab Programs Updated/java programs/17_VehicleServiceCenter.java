package q107863;
import java.util.Scanner;

class Vehicle {

    String model;
    int year;
    Vehicle(String m,int y)
    {
        this.model=m;
        this.year=y;
    }
    void service ()
    {

    }

}

class Car extends Vehicle {

    int numberOfDoors;
    Car(String m,int y,int nd)
    {
        super(m,y);
        this.numberOfDoors=nd;
    }
    void service()
    {
        System.out.printf("Vehicle Details\nModel: %s\n",model);
        System.out.printf("Year: %d\nDoors: %d\n",year,numberOfDoors);
        System.out.println("Service Procedure");
        System.out.println("oil change brake check tire rotation");
    }

}

class Bike extends Vehicle {
    boolean hasABS;
    Bike(String m,int y,boolean hA)
    {
        super(m,y);
        this.hasABS=hA;
    }
    void service()
    {
        System.out.printf("Vehicle Details\nModel: %s\nYear: %d\n",model,year);
        String abs= hasABS?"Yes":"No";
        System.out.println("ABS: "+abs);
        System.out.println("Service Procedure");
        System.out.println("chain lubrication brake adjustment air check");
    }

}

public class VehicleServiceCenter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Vehicle Service Center");
        System.out.println("1. Car");
        System.out.println("2. Bike");

        int choice = sc.nextInt();
        sc.nextLine();

        Vehicle vehicle = null;

        switch (choice) {
            case 1:
                String carModel = sc.nextLine();
                int carYear = sc.nextInt();
                int doors = sc.nextInt();
                vehicle = new Car(carModel, carYear, doors);
                break;

            case 2:
                String bikeModel = sc.nextLine();
                int bikeYear = sc.nextInt();
                boolean hasABS = sc.nextBoolean();
                vehicle = new Bike(bikeModel, bikeYear, hasABS);
                break;
        }

        if (vehicle != null) {
            vehicle.service();
        }

        sc.close();
    }
}
