package q79655;
import java.util.Scanner;

class Calculator {

    int addfunc(int x,int y)
    {
        return x+y;
    }
    double addfunc(double x,double y)
    {
        return x+y;
    }

}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create Calculator object
        Calculator calc = new Calculator();

        // Read two integers
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();

        // Read two doubles
        double num3 = scanner.nextDouble();
        double num4 = scanner.nextDouble();

        // Call addfunc with integers
        int intSum = calc.addfunc(num1, num2);
        System.out.println(intSum);

        // Call addfunc with doubles
        double doubleSum = calc.addfunc(num3, num4);
        System.out.printf("%.2f%n", doubleSum);

        scanner.close();
    }
}
