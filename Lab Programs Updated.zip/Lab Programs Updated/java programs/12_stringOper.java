package q110253;
import java.util.Scanner;
import java.util.*;
public class stringOper {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String str1,str2;
        str1=sc.nextLine();
        str2=sc.nextLine();

        System.out.println("Character at index 5 : "+str1.charAt(5));

        System.out.println("Starts with 'k' : "+(str2.charAt(0)=='k'));

        System.out.println("Length of str1 : "+str1.length());
        System.out.println("Length of str2 : "+str2.length());

        System.out.println("Strings are equal : "+str1.equals(str2));

        System.out.println("Substring (1,4) : "+(str1.substring(1,4)));

        char dst[]=new char[2];
        dst[0]='a';
        dst[1]='b';

        System.out.println("Character Array : "+String.valueOf(dst));

        char dst1[]=new char[5];
        System.out.print("Updated Character Array : ");
        str1.getChars(0,Math.min(str1.length(),5),dst1,0);
        System.out.println(String.valueOf(dst1));

        System.out.println("Concatenated String : "+str2.concat(" Programming"));

        sc.close();
    }
}
