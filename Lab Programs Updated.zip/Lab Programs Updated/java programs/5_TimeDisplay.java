package q109638;
import java.util.Scanner;

class Time {

    int hours=00;
    int minutes=00;
    int seconds=00;
    Time()
    {

    }
    Time(int h3,int m3,int s3)
    {
        hours=h3;
        minutes=m3;
        seconds=s3;
    }

    Time(int h2,int m2)
    {
        hours=h2;
        minutes=m2;

    }
    Time(int h1)
    {
        hours=h1;

    }

    void displayTime() {
        System.out.printf("%02d:%02d:%02d%n", hours, minutes, seconds);
    }
}

public class TimeDisplay {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int h1 = sc.nextInt();

        int h2 = sc.nextInt();
        int m2 = sc.nextInt();

        int h3 = sc.nextInt();
        int m3 = sc.nextInt();
        int s3 = sc.nextInt();

        Time t1 = new Time();
        Time t2 = new Time(h1);
        Time t3 = new Time(h2, m2);
        Time t4 = new Time(h3, m3, s3);

        t1.displayTime();
        t2.displayTime();
        t3.displayTime();
        t4.displayTime();

        sc.close();
    }
}
