package q55527;
import java.util.Scanner;

public class StringBufferExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your code here...
        String inputString=scanner.nextLine();
        int index=scanner.nextInt();

        StringBuffer stringBuffer = new StringBuffer(inputString);
        if(index>=0&&index<stringBuffer.length())
        {
            stringBuffer.deleteCharAt(index);
            System.out.println(stringBuffer);
        }
        else
        {
            System.out.println("invalid position");
        }

        scanner.close();
    }
}
