package q18020;
import java.util.Scanner;
class Parents {
    void add(int num1,int num2)
    {
        System.out.println("Addition: "+(num1+num2));
    }
}

class Child extends Parents {

    void sub(int num1,int num2)
    {
        super.add(num1,num2);
        System.out.println("Subtraction: "+(num1-num2));
    }
}

public class SumandSub {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input two integers
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();

        // Create Child object and call sub method
        Child obj = new Child();
        obj.sub(num1, num2);

        sc.close();
    }
}
