package q105748;
import java.util.Scanner;

class Shape {
    void calculateArea() {
        System.out.println("0.00");
    }
}

class Polygon extends Shape {
    int sides;
    double sideLength;

    Polygon(int sides, double sideLength) {
        this.sides=sides;
        this.sideLength=sideLength;
    }

    @Override
    void calculateArea() {
        double perimeter =sides*sideLength;
        System.out.printf("%.2f\n",perimeter);
    }
}

class Triangle extends Polygon {
    double height;

    Triangle(int sides, double sideLength, double height) {
        super(sides,sideLength);
        this.height=height;
    }

    @Override
    void calculateArea() {
        double area =0.5*sideLength*height;
        System.out.printf("%.2f\n",area);
    }
}

public class ShapeHierarchy {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int sides = sc.nextInt();
        double sideLength = sc.nextDouble();
        double height = sc.nextDouble();
        Shape shape = new Shape();
        Shape polygon = new Polygon(sides, sideLength);
        Shape triangle = new Triangle(sides, sideLength, height);
        shape.calculateArea();
        polygon.calculateArea();
        triangle.calculateArea();
    }
}
