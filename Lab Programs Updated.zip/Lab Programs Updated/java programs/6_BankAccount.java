package q103045;
import java.util.Scanner;

public class BankAccount {
    String name;
    double balance;

    BankAccount(String name, double balance) {
        this.name = name;
        this.balance =balance;
    }

    void deposit(double amount) {
        this.balance=balance+amount;
        System.out.printf("Balance after deposit: %.2f\n",balance);
    }

    void withdraw(double amount) {
        if(balance>amount)
        {
            this.balance=balance-amount;
            System.out.printf("Balance after withdrawal: %.2f\n",balance);
        }
        else
        {
            System.out.printf("Insufficient balance\n");
        }
    }

    void displayBalance() {
        System.out.printf("Current balance: %.2f\n",balance);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        double balance = sc.nextDouble();
        int q = sc.nextInt();
        sc.nextLine();
        BankAccount account = new BankAccount(name, balance);
        for (int i = 0; i < q; i++) {
            String line = sc.nextLine();
            String[] parts = line.split(" ");
            if (parts[0].equals("deposit")) {
                account.deposit(Double.parseDouble(parts[1]));
            } else if (parts[0].equals("withdraw")) {
                account.withdraw(Double.parseDouble(parts[1]));
            } else if (parts[0].equals("display")) {
                account.displayBalance();
            }
        }
    }
}
