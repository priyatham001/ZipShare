package q29082;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ExamScoreManager {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> examScores = new ArrayList<>();
        int n=scanner.nextInt();
        examScores.add(n);
        while (n>0)
        {
            n=scanner.nextInt();
            if(n>0)
                examScores.add(n);
        }
        Collections.sort(examScores);
        int i;
        for( i=0;i<examScores.size()-1;i++)
            System.out.print(examScores.get(i)+" ");
        System.out.print(examScores.get(i++));
    }
}
