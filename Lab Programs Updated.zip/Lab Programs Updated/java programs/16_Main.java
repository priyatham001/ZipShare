package q35629;
import java.util.Scanner;

abstract class Shape {
    abstract void printArea();
    double dimension1,dimension2;
    Shape(double dimension1,double dimension2)
    {
        this.dimension1=dimension1;
        this.dimension2=dimension2;
    }
}

class Rectangle extends Shape {
    double l,w;
    Rectangle(double l,double w)
    {
        super(l,w);
    }
    void printArea()
    {
        System.out.printf("Area of Rectangle: %.2f\n",dimension1*dimension2);
    }
}

class Triangle extends Shape {
    double b,h;
    Triangle(double b,double h)
    {
        super(b,h);
    }
    void printArea()
    {
        System.out.printf("Area of Triangle: %.2f\n",0.5*dimension1*dimension2);
    }
}

class Circle extends Shape {
    double r;
    Circle(double r)
    {
        super(r,r);
    }
    void printArea()
    {
        System.out.printf("Area of Circle: %.2f\n",Math.PI*dimension1*dimension2);
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Length and Width of Rectangle: ");
        double length = scanner.nextDouble();
        double width = scanner.nextDouble();
        Rectangle rectangle = new Rectangle(length, width);
        rectangle.printArea();

        System.out.print("Base and Height of Triangle: ");
        double base = scanner.nextDouble();
        double height = scanner.nextDouble();
        Triangle triangle = new Triangle(base, height);
        triangle.printArea();

        System.out.print("Radius of Circle: ");
        double radius = scanner.nextDouble();
        Circle circle = new Circle(radius);
        circle.printArea();

        scanner.close();
    }
}
