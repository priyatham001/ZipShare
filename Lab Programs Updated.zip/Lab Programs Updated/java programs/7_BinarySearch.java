package q35300;

import java.util.Scanner;

public class BinarySearch {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int n=sc.nextInt();
        int a[]= new int[n];
        int i;
        for(i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        int key=sc.nextInt();
        int l=0,h=n-1;
        while(l<=h)
        {
            int mid = (l+h)/2;
            if(a[mid]==key)
            {
                System.out.println(mid);
                return;
            }
            else if(a[mid]<key)
            {
                l=mid+1;
            }
            else{
                h=mid-1;
            }
        }
        if(l>h)
        {
            System.out.println("Element not found");
        }
        sc.close();
    }
}
