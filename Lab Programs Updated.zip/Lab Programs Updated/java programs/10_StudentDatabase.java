package q30073;
import java.util.*;

public class StudentDatabase {
    public static void main(String[] args) {
        Map<Integer, String> studentDatabase = new HashMap<>();
        Scanner sc =new Scanner(System.in);
        int n = sc.nextInt();
        for(int i=0;i<n;i++)
        {
            int id=sc.nextInt();
            sc.nextLine();
            String name=sc.nextLine();

            studentDatabase.put(id,name);
        }

        for(Integer i: studentDatabase.keySet())
        {
            System.out.println(i+" "+studentDatabase.get(i));
        }

        sc.close();
    }
}
