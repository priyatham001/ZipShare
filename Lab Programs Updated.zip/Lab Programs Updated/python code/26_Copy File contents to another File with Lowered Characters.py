input_file=input()
output_file=input()
with open(input_file,'r') as fi:
	words=fi.read().lower().split()
with open(output_file,'w+') as f:
	for word in words:
		f.write(word+'\n')
	f.seek(0)
	print(f.read())
