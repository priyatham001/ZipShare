s1=input()
s2=input()
if s1 in s2 or s2 in s1:
	print("Exists")
else :
	print("Does not exist")
