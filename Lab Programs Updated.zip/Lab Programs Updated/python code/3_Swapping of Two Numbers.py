# take user inputs
num1=int(input("num1: "))
num2=int(input("num2: "))
print("numbers before swapping : {} {}".format(num1, num2))
num1=num1+num2
num2=num1-num2
num1=num1-num2
print("numbers after swapping : {} {}".format(num1, num2))
