# Type Content here...
li=list(map(int,input().split()))
sum=0
li.sort()
for x in li:
	sum=sum+x
print(len(li))
print(li[-1])
print(li[0])
print(sum)
print(li)
