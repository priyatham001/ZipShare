# Type Content here...
a,b=map(int,input().split())
c,d=map(int,input().split())
a1=a+c
a2=b+d
m1=a*c-b*d
m2=a*d+c*b
print(f"{a1} + {a2}i")
print(f"{m1} + {m2}i")
