import math

# Shape class
class Shape:
	def __init__(self,a):
		self.a=a
	
	def area(self): 
		return self.a*self.a
	def perimeter(self): 
		return 4*self.a
# Circle subclass
class Circle(Shape):
	def __init__(self,a):
		self.a=a
	def area(self): 
		return math.pi*self.a*self.a
	def perimeter(self): 
		return math.pi*2*self.a
# Triangle subclass
class Triangle(Shape):
	def __init__(self,a,b,c):
		self.a=a
		self.b=b
		self.c=c
	def area(self):
		s=(self.a+self.b+self.c)/2
		return math.sqrt(s*(s-self.a)*(s-self.b)*(s-self.c))
	def perimeter(self): 
		return self.a+self.b+self.c
# Square subclass
class Square(Shape):
	pass

r=float(input())
a,b,c=map(float,input().split())
s=float(input())
circle=Circle(r)
triangle=Triangle(a,b,c)
square=Square(s)
print(f"{circle.area():.2f} {circle.perimeter():.2f}")
print(f"{triangle.area():.2f} {triangle.perimeter():.2f}")
print(f"{square.area():.2f} {square.perimeter():.2f}")
