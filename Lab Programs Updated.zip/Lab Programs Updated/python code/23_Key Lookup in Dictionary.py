keys=tuple(input().split())
values=tuple(input().split())
if len(keys)!=len(values):
	print("Invalid")
else:
	dict={}
	for i in range(len(keys)):
		dict[keys[i]]=values[i]
	x=input()
	print(dict)
	if x in keys:
		print("Exist")
	else:
		print("Does not Exist")
