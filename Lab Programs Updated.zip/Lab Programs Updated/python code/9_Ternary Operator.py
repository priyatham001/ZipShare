x = int(input())
y = int(input())
max_value =x if x>y else y
print(max_value)
