# write the code...
num1=int(input("num1: "))
num2=int(input("num2: "))
print("Addition of",num1,"and",num2,"=",num1+num2)
print("Subtraction of",num1,"and",num2,"=",num1-num2)
print("Multiplication of",num1,"and",num2,"=",num1*num2)
print("Division of",num1,"and",num2,"=",num1/num2)
