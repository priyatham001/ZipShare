#write your code here...

x=int(input())
for i in range(1,11):
	print(f"{x} x {i} = {x*i}")
