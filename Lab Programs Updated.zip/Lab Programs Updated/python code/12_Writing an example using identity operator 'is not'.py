a=int(input("Enter an integer value: "))
b=int(input("Enter an integer value: "))
print(f"{a} is not {b} {a is not b}")
