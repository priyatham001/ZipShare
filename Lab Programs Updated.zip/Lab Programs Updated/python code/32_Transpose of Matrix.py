r,c=map(int,input().split())
l=[]
for i in range(r):
	l.append(list(map(int,input().split())))
for i in range(c):
	for j in range(r):
		print(l[j][i],end="")
		if j< r-1:
			print(end=" ")
	print()
