num_list = [1, 2, 3, 4, 5, 15, 25, 89, 54, 123, 489]
# Write your code here...
a=int(input())
print(a in num_list)
print(a not in num_list)
