# Write your code here...
a=int(input())
b=int(input())

print(f"{a} and {b}: {a and b}")
print(f"{a} or {b}: {a or b}")
print(f"not {a}: {not a}")
print(f"not {b}: {not b}")
