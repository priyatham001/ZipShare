import numpy as np

# Create a 3x3 NumPy array
array = np.array([[1, 2, 3],
                  [4, 5, 6],
                  [7, 8, 9]])
print(array)

# Indexing: Accessing individual elements


print("Accessing")
i,j=map(int,input().split())
print(array[i,j])
print("Slicing")
m,n=map(int,input().split())
p,q=map(int,input().split())
print(array[m:n,p:q])
