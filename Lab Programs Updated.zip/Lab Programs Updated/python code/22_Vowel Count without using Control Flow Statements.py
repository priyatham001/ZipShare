s = input()
s=s.lower()
vowels = {'a':s.count('a'),'e':s.count('e'),'i':s.count('i'),'o':s.count('o'),'u':s.count('u')}

count = sum(vowels.values())

print(count)
