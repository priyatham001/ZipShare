l=list(input().split())
x=input()
i=int(input())
e=input()
print(l)
l.append(x)
print(l)
if i>len(l):
	print("Invalid index")
else:
	l.insert(i,e)
	print(l)
print(l[::-1])
