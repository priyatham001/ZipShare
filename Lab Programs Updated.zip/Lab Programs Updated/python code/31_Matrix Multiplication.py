def matrix_multiplication():
	r1,c1=map(int,input().split())
	a=[]
	for i in range(r1):
		t=list(map(int,input().split()))
		a.append(t)
	r2,c2=map(int,input().split())
	b=[]
	for i in range(r2):
		t=list(map(int,input().split()))
		b.append(t)
	if c1!=r2:
		print("Invalid")
	else:
		c=[[0]*c2 for i in range(r1)]
		for i in range(r1):
			for j in range(c2):
				c[i][j]=0
				for k in range(c1):
					c[i][j]+=a[i][k]*b[k][j]
		for i in range(r1):
			for j in range(c2):
				print(c[i][j],end="")
				if j<c2-1:
					print(" ",end="")
			print()

# Call the function to run matrix multiplication
matrix_multiplication()
