import numpy as np

# Take inputs from the user
start = int(input( ))
end = int(input( ))

# Create an array with values ranging from start to end
array = np.arange(start,end+1)

# Display the array
print(array)
