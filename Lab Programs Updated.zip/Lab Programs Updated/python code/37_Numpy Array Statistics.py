import numpy as np
li=list(int(x) for x in input().split())
arr=np.array(li)
print(arr)
print(np.min(arr))
print(np.max(arr))
print(np.sum(arr))
