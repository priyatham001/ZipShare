import numpy as np
li=list(int(x) for x in input().split())
arr=np.array(li)
print(arr)
print(np.ndim(arr))
print(np.shape(arr))
print(np.size(arr))
print(arr.dtype)
