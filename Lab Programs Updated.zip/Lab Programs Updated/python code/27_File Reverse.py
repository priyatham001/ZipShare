import os
input_file=input()
if(os.path.exists(input_file)):
	with open(input_file,'r') as f:
		ss=f.readlines()
		for s in ss:
			print(s.strip()[::-1])
else:
	print("File not found")
