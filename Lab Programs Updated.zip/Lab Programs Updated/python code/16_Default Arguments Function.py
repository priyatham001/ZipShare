# Define a function with default arguments
def greet(name,age,country):
	print(f"Hello, {name}! You are {age} years old and you are from {country}")


# Get user input function
def get_user_input():
	name=input("-1 for default: ")
	if name == "-1":
		name="Dude"
	age=int(input("-1 for default: "))
	if age == -1:
		age = 0
	country=input("-1 for default: ")
	if country == "-1":
		country="Space"
	return name,age,country

name, age, country = get_user_input()
greet(name, age, country)
