keys=input().split()
values=input().split()
if len(keys)!=len(values):
	print("Invalid")
else:
	d=dict(zip(keys,values))
	n=input().split()
	print(d)
	d[n[0]]=n[1]
	print(d)
