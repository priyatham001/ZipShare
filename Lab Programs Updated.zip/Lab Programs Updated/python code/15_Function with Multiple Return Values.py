def calculate_stats(numbers):
	total=0
	max=numbers[1]
	c=0
	for i in numbers:
		total=int(i)+total
		if max<i:
			max=i
		c=c+1
	return total,total/c,max
	

numbers = list(map(int, input().split()))
total, mean, maximum = calculate_stats(numbers)
print(total)
print(f"{mean:.2f}")
print(maximum)
