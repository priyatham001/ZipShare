s=int(input("size:"))
d={}
for i in range(0,s):
	k=input("key:")
	v=int(input("value:"))
	d[k]=v
print(f"Sum:{sum(d.values())}")
