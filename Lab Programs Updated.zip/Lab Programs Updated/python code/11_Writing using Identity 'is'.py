a=int(input("Enter an integer value: "))
b=int(input("Enter an integer value: "))
print(f"{a} is {b} {a is b}")
