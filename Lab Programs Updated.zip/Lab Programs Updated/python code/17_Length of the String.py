def string_length(s):
	c=0
	for x in s:
		c+=1
	return c
input_string = input() # Taking user input
length = string_length(input_string) # Calculating length using the function
print(length) # Printing the length
