# Type Content here...
list1=list(map(int,input().split()))
new1=list(map(int,input().split()))
slice=list(map(int,input().split()))
print(list1)
list1.insert(new1[0],new1[1])
print(list1)
print(list1[slice[0]:slice[1]])
