# Write your code here
a=int(input())
b=int(input())
a+=b
print(f"a+=b: a= {a} b= {b}")
a-=b
print(f"a-=b: a= {a} b= {b}")
a*=b
print(f"a*=b: a= {a} b= {b}")
a/=b
print(f"a/=b: a= {a} b= {b}")
a**=b
print(f"a**=b: a= {a} b= {b}")
a//=b
print(f"a//=b: a= {a} b= {b}")
a%=b
print(f"a%=b: a= {a} b= {b}")
a=b
print(f"a=b a= {a} b= {b}")
