r1,c1=map(int,input().split())
l1=[]
for i in range(0,r1):
	a=list(map(int,input().split()))
	l1.append(a)
r2,c2=map(int,input().split())
l2=[]
for i in range(0,r2):
	a=list(map(int,input().split()))
	l2.append(a)
if r1!=r2 or c1!=c2:
	print("Invalid")
else:
	for i in range(0,r1):
		for j in range(0,c2):
			print(l1[i][j]+l2[i][j],end="")
			if j<c2-1:
				print(" ",end="")
		print()
