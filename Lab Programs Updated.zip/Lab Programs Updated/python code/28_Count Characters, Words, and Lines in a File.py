file_name=input()
with open(file_name,"r") as f:
	c=f.read()
	print(len(c))
	print(len(c.split()))
	print(len(c.split('\n')))
