CREATE OR REPLACE FUNCTION update_insert_count()
RETURNS TRIGGER AS
$$
BEGIN
	update employee_audit
	set insert_count = insert_count + 1;
	return null;
END;
$$ LANGUAGE plpgsql;
create trigger employee_insert_count
after insert on employees
for each STATEMENT
execute function update_insert_count();
