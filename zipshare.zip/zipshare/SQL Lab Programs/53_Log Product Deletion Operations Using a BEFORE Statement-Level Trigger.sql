CREATE OR REPLACE FUNCTION log_delete_operation()
RETURNS TRIGGER AS
$$
BEGIN
  -- write your code here...
insert into delete_log(log_id, operation)
	values(2, 'Delete Operation Started');
return null;



END;
$$ LANGUAGE plpgsql;
-- Create the statement-level trigger
create trigger before_product_delete
before delete on products
for each STATEMENT
execute function log_delete_operation();
