-- Table Creation
create table movies(
	movie_id SERIAL Primary Key,
	movie_title VARCHAR(255),
	genre VARCHAR(255),
	rating DECIMAL
);

-- Data Insertion
INSERT INTO movies (movie_id, movie_title, genre, rating) values
(1, 'Galaxy War', 'Sci-Fi', 8.7),
(2, 'Silent Night', 'Horror', 7.9),
(3, 'Happy Days', 'Comedy', 8.2),
(4, 'Alien Planet', 'Sci-Fi', 8.8),
(5, 'Jungle Quest', 'Adventure', 8.4),
(6, 'Secret Agent', 'Thriller', 8.6);

-- Search without index
SELECT * FROM movies where genre = 'Sci-Fi';

-- Create index
CREATE index idx_genre on movies (genre);

-- Search using index
SELECT * from movies where genre = 'Sci-Fi';
