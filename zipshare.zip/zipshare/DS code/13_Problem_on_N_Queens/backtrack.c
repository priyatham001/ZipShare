#include <stdio.h>
int N;
int board[100][100];


int is_attack(int i,int j) {
	
    for(int k=0;k<N;k++)
		{
			if(board[i][k]==1)
				return 1;
		}
	for(int k=0;k<N;k++)
		{
			if(board[k][j]==1)
				return 1;
		}
    int x=i-1;
	int y=j-1;
	while(x>=0&&y>=0)
		{
			if(board[x][y]==1)
				return 1;
			x--;
			y--;
		}
	x=i-1;
	y=j+1;
	while(x>=0&&y<N)
		{
			if(board[x][y]==1)
				return 1;
			x--;
			y++;
		}
	x=i+1;
	y=j-1;
	while(x<N&&y>=0)
		{
			if(board[x][y]==1)
				return 1;
			x++;
			y--;
		}
	x=i+1;
	y=j+1;
	while(x<N&&y<N)
		{
			if(board[x][y]==1)
				return 1;
			x++;
			y++;
		}
	return 0;
}

int N_queen(int n) {
    int i,j;
    if(n == 0)
        return 1;
    
    for(i=0;i<N;i++)
			for(j=0;j<N;j++)
					if(board[i][j]==0&&is_attack(i,j)==0)
					{
						board[i][j]=1;
						if(N_queen(n-1))
							return 1;
						board[i][j]=0;
					}

	return 0;
}

int main() {
    printf("Enter the value of N for NxN chessboard: ");
    scanf("%d",&N);

    int i,j;
    for(i = 0 ;i < N; i++) {
        for(j = 0; j < N; j++) {
            board[i][j] = 0;
        }
    }
    N_queen(N);
    for(i = 0 ;i < N; i++) {
        for(j = 0; j < N; j++)
            printf("%d\t",board[i][j]);
        printf("\n");
    }
}
