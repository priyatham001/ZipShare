#include <stdio.h>
#include <stdlib.h>

int knapsack(int *wt, int *val, int W, int n, int **t) {
	
		if(n==0||W==0)
			return 0;
		if(t[n][W]!=-1)
			return t[n][W];
	if(wt[n-1]<=W)
	{
		int include=val[n-1]+knapsack(wt,val,W-wt[n-1],n-1,t);
		int exclude=knapsack(wt,val,W,n-1,t);
		if(include>exclude)
			t[n][W]=include;
		else
			t[n][W]=exclude;
	}
	else{
		t[n][W]=knapsack(wt,val,W,n-1,t);
	}
	return t[n][W];

}

int main() {
    int n;

    scanf("%d", &n);

    int *weights = (int *)malloc(n * sizeof(int));
    int *values = (int *)malloc(n * sizeof(int));

    // Read weights of items in a single line
    for (int i = 0; i < n; i++) {
        scanf("%d", &weights[i]);
    }

    // Read values of items in a single line
    for (int i = 0; i < n; i++) {
        scanf("%d", &values[i]);
    }

    int capacity;
    scanf("%d", &capacity);

    // Initialize the memoization table with -1
    int **t = (int **)malloc((n + 1) * sizeof(int *));
    for (int i = 0; i <= n; i++) {
        t[i] = (int *)malloc((capacity + 1) * sizeof(int));
        for (int j = 0; j <= capacity; j++) {
            t[i][j] = -1;
        }
    }

    int max_profit = knapsack(weights, values, capacity, n, t);

    printf("%d\n", max_profit);

    // Free allocated memory
    for (int i = 0; i <= n; i++) {
        free(t[i]);
    }
    free(t);
    free(weights);
    free(values);

    return 0;
}
