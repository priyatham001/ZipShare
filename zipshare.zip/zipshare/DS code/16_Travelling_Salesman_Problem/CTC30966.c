#include <stdio.h>
int n, a[20][20], v[20], best = 9999999;

void f(int city, int count, int cost) {
	    if (count == n) {
			        if (a[city][0] != -1 && cost + a[city][0] < best)
						            best = cost + a[city][0];
			        return;
		}
		for(int i = 1; i < n; i++) {
			        if (v[i] == 0 && a[city][i] != -1) {
						            v[i] = 1;
						            f(i, count + 1, cost + a[city][i]);
						            v[i] = 0;
					}
			}
}

int main() {
        scanf("%d", &n);
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
						scanf("%d", &a[i][j]);
	    f(0, 1, 0);
	    if (best == 9999999) printf("-1");
	    else printf("%d",best);
}
