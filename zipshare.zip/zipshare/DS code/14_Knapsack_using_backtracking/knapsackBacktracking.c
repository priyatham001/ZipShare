#include <stdio.h>
#include <stdlib.h>

int knapsack(int *weights, int *values, int capacity, int n) {

		     if (n == 0 || capacity == 0)
				         return 0;
		     if (weights[n - 1] > capacity)
				         return knapsack(weights, values, capacity, n - 1);
		     int include = values[n - 1] + knapsack(weights, values, capacity - weights[n - 1], n - 1);
		     int exclude = knapsack(weights, values, capacity, n - 1);
		     return (include > exclude) ? include : exclude;
	
}


int main() {
    int n;

    // Read number of items
    scanf("%d", &n);

    // Allocate memory for values and weights
    int *values = (int *)malloc(n * sizeof(int));
    int *weights = (int *)malloc(n * sizeof(int));

    // Read values and weights of items
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &values[i],&weights[i]);
    }

    int capacity;
    scanf("%d", &capacity);

    // Calculate and print the maximum profit
    printf("%d\n", knapsack(weights, values, capacity, n));

    // Free allocated memory
    free(values);
    free(weights);

    return 0;
}
