import pandas as pd

data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 'Frank', 'Grace', 'Hannah', 'Ian', 'Julia'],
    'Age': [25, 30, 22, 28, 24, 27, 29, 23, 26, 31],
    'Department': ['HR', 'Finance', 'IT', 'HR', 'Finance', 'IT', 'HR', 'Finance', 'IT', 'HR'],
    'Salary': [50000, 60000, 55000, 52000, 61000, 53000, 58000, 62000, 54000, 57000],
    'Experience': [2, 4, 1, 3, 2, 2, 5, 4, 3, 6]
}

# Step 1: Convert the dictionary to a pandas DataFrame
df=pd.DataFrame(data)

# Step 2: Perform the following operations exactly as instructed
# a) Display the first 5 rows of the DataFrame
print(df.head())

# b) Select and display only the 'Name' and 'Salary' columns
print(df[['Name','Salary']])

# c) Display all rows where 'Age' is greater than 25
print(df[df['Age']>25])

# d) Display all rows where 'Department' is 'IT'
print(df[df["Department"]=="IT"])

# e) Display all rows where both 'Age' > 25 and 'Salary' > 55000
print(df[(df['Age']>25) & (df['Salary']>55000)])
