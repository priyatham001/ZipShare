import numpy as np
li=list(int(x) for x in input().split())
arr=np.array(li)
print(np.median(arr))
print(np.cumsum(arr))
print(np.cumprod(arr))
