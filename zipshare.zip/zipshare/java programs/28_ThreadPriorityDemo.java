class MyThread extends Thread {
    MyThread(String name)
    {
        super(name);
    }

@Override
    public void run()
    {
        System.out.println("Thread "+Thread.currentThread().getName()+" with priority "+Thread.currentThread().getPriority()+" started");
        System.out.println("Thread "+Thread.currentThread().getName()+" with priority "+Thread.currentThread().getPriority()+" finished");
    }

}

public class ThreadPriorityDemo {
    public static void main(String[] args) {
        // Create three threads with different names
        MyThread thread1 = new MyThread("HighPriority");
        MyThread thread2 = new MyThread("MediumPriority");
        MyThread thread3 = new MyThread("LowPriority");

        // Set priorities
        thread1.setPriority(Thread.MAX_PRIORITY);   // Priority 10
        thread2.setPriority(Thread.NORM_PRIORITY);  // Priority 5
        thread3.setPriority(Thread.MIN_PRIORITY);   // Priority 1

        // Start all threads
        thread1.start();
        thread2.start();
        thread3.start();

        // Wait for all threads to complete
        try {
            thread1.join();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
