import java.util.Scanner;

// Runnable class for Fibonacci series
class FibonacciTask implements Runnable {

    int n;
    FibonacciTask(int n)
    {
        this.n=n;
    }
    public void run()
    {
        StringBuilder sb=new StringBuilder();
        int t1=0;
        int t2=1;
        for (int i=0;i<n;i++)
            {
                if(i>0)
                sb.append(" ");
                sb.append(t1);
                int next=t1+t2;
                t1=t2;
                t2=next;

            }
        System.out.println(sb);
    }

}

// Runnable class for even numbers in range
class EvenNumberTask implements Runnable {

    int start,end;
    EvenNumberTask(int start,int end)
    {
        this.start=start;
        this.end=end;
    }
    public void run()
    {
        StringBuilder sb=new StringBuilder();
        for(int i=start;i<=end;i++)
        {
            if(i%2==0)
            {
                if(sb.length()>0)
                sb.append(" ");
                sb.append(i);
            }
        }
    System.out.println(sb);
    }
}

// Main class
public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int start = sc.nextInt();
        int end = sc.nextInt();
        // Create runnable objects
        FibonacciTask r1=new FibonacciTask(n);
        EvenNumberTask r2=new EvenNumberTask(start,end);
        // Create thread objects
        Thread t1=new Thread(r1);
        Thread t2=new Thread(r2);
        // Start threads
        t1.start();
        t2.start();

        sc.close();
    }
}
