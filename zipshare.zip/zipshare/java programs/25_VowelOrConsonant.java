import java.util.Scanner;
class InvalidCharacterException extends Exception {
    public InvalidCharacterException(String message){
    super(message);
    }
}
public class VowelOrConsonant {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            String input = scanner.nextLine();
            if(input.length()!=1)
                throw new InvalidCharacterException("Input should be a single character");
            char ch= input.charAt(0);
            if(!Character.isLetter(ch))
                throw new InvalidCharacterException("Input should be a letter");
            ch=Character.toLowerCase(ch);
            if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
                System.out.println("Vowel");
            else
                System.out.println("Consonant");
        } catch (InvalidCharacterException e) {
            System.out.println("Invalid Input: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
