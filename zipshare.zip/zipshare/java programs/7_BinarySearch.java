import java.util.Scanner;

public class BinarySearch {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int n=sc.nextInt();
        int a[]= new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        int k=sc.nextInt();
        int l=0,h=n-1;
        while(l<=h)
            {
                int mid=(l+h)/2;
                if(a[mid]==k)
                {
                    System.out.println(mid);
                    return ;
                }
                else if(a[mid]>k)
                    h=mid-1;
                else
                    l=mid+1;
            }

        System.out.println("Element not found");

    }
}
