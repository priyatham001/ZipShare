class GoodMorningThread extends Thread
    {
        @Override
        public void run()
        {
            for(int i=0;i<5;i++)
            System.out.println("Good Morning");
        }
    }
class HelloThread extends Thread
    {
        @Override
        public void run()
        {
            for(int i=0;i<5;i++)
            System.out.println("Hello");
        }
    }
class WelcomeThread extends Thread
    {
        @Override
        public void run()
        {
            for(int i=0;i<5;i++)
            System.out.println("Welcome");
        }
    }

public class MultiThreadMessages {
    public static void main(String[] args) {
        GoodMorningThread t1 = new GoodMorningThread();
        HelloThread t2 = new HelloThread();
        WelcomeThread t3 = new WelcomeThread();

        t1.start();
        t2.start();
        t3.start();
    }
}
