import java.util.Scanner;

public class NullPointerExample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Take the first input string from the user
        String s1=scanner.nextLine();
        // Take the second input string from the user
        String s2=scanner.nextLine();
        try {
            // Simulate NullPointerException if either of the inputs is "null"
            if(s1.equals("null")){
                s1=null;
            }
            if(s2.equals("null")){
                s2=null;
            }
            if(s1==null||s2==null)
                throw new NullPointerException();
            // Output the lengths of both strings
            System.out.printf("%d\n%d\n",s1.length(),s2.length());
        } catch (NullPointerException npe) {
            // Handle NullPointerException
        System.out.println("NullPointerException");
        }
        scanner.close();
    }
}
