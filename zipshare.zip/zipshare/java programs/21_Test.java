import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the numerator: ");
        int numerator = sc.nextInt();

        System.out.println("Enter the denominator: ");
        int denominator = sc.nextInt();

        try {
            System.out.println("Result of division: "+numerator/denominator);
        } catch (ArithmeticException ae) {
            System.out.println("ArithmeticException: Division by zero is not allowed");
        }
        finally {
           System.out.println("Finally Block Executed");
        }
    }
}
