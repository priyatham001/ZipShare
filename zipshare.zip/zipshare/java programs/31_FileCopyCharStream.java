import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileCopyCharStream {

        public static void copyFile(String sourceF,String destF) throws IOException
    {
        FileReader r= new FileReader(sourceF);
        FileWriter w= new FileWriter(destF);
        int c;
        while((c=r.read())!=-1)
            w.write(c);
        r.close();
        w.close();
    }
    public static String readFile(String fileName) throws IOException {
        StringBuilder content = new StringBuilder();

        try (FileReader reader = new FileReader(fileName)) {
            int charData;
            while ((charData = reader.read()) != -1) {
                content.append((char) charData);
            }
        }

        return content.toString();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String sourceFile = sc.nextLine();
        String destFile = sc.nextLine();

        try {
            // Step 1: Copy file using character streams
            copyFile(sourceFile, destFile);

            System.out.println("Contents copied successfully");

            // Step 2: Read and display destination file contents
            String destContent = readFile(destFile);
            System.out.print(destContent);

        } catch (IOException e) {
            System.out.println("An error occurred while copying the file.");
        }

        sc.close();
    }
}
