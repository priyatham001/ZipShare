import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileCopyByteStream {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String sourceFile = sc.nextLine();
        String destFile = sc.nextLine();
    try(FileInputStream fs = new FileInputStream(sourceFile);
        FileOutputStream fos=new FileOutputStream(destFile))
        {
            int asci;
            while((asci=fs.read())!=-1)
            {
                fos.write((char)asci);
            }
        }
        catch(IOException e)
            {
                System.out.println("Error: "+e.getMessage());
            }

        // Display confirmation and the copied contents
        System.out.println("Contents copied successfully");

        try (FileInputStream fis = new FileInputStream(destFile)) {

            int data;

            while ((data = fis.read()) != -1) {
                System.out.print((char) data);
            }

        } catch (IOException e) {
            System.out.println("An error occurred while reading the destination file.");
        }

        sc.close();
    }
}
