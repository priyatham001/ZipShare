import java.util.Scanner;

public class ExceptionHandlingDemo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Size of the array: ");
            int size = scanner.nextInt();
            int[] numbers = new int[size];

            System.out.print("Index: ");
            int index = scanner.nextInt();
            System.out.println(numbers[index]);

        } catch (ArrayIndexOutOfBoundsException ae) {
            System.out.println("ArrayIndexOutOfBoundsException: Invalid index entered.");
        } catch (NumberFormatException ne) {
            System.out.println("NumberFormatException: Invalid number format.");
        } finally {
            scanner.nextLine();
        }

        try {
            System.out.print("Number as string: ");
            String input = scanner.nextLine();
            int number = Integer.parseInt(input);
            System.out.println("Parsed number: " + number);

        } catch (NumberFormatException ne) {
            System.out.println("NumberFormatException: Invalid number format.");
        }

        try {
            System.out.print("Numerator: ");
            int numerator = scanner.nextInt();
            System.out.print("Denominator: ");
            int denominator = scanner.nextInt();

            double result = numerator / denominator;
            System.out.println("Result: " + result);

        } catch (ArithmeticException ae) {
            System.out.println("ArithmeticException: Division by zero or invalid arithmetic operation.");
        } finally {
            scanner.close();
        }
    }
}
