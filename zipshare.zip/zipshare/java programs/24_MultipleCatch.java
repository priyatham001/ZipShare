import java.util.Scanner;

public class MultipleCatch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {

            int n;
            n=sc.nextInt();
            int a[]=new int[n];
            for(int i=0;i<n;i++)
                {
                    a[i]=sc.nextInt();
                }
            int i=sc.nextInt();
            System.out.println(a[i]);

        } catch (NegativeArraySizeException e) {
            System.out.println("Negative array size");

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Index out of bounds");
        } catch (java.util.InputMismatchException e) {
            System.out.println("Invalid input");
        }
    }
}
